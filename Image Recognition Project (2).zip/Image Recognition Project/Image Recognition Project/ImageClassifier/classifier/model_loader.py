# classifier/model_loader.py
import tensorflow as tf
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.models import Model

# Load pretrained ResNet50
model = ResNet50(weights="imagenet")
model.save("resnet50_model.h5")
