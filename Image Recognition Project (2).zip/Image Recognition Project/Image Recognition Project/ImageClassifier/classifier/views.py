# classifier/views.py
from django.shortcuts import render
from django.conf import settings
from .models import UploadedImage
from .utils import predict
import os

def upload_image(request):
    if request.method == "POST":
        uploaded_image = UploadedImage(image=request.FILES['image'])
        uploaded_image.save()

        # Perform prediction
        image_path = uploaded_image.image.path
        class_name, confidence = predict(image_path)

        # Get the image name and URL
        image_name = os.path.basename(uploaded_image.image.name)
        uploaded_image_url = uploaded_image.image.url

        return render(request, "result.html", {
            "class_name": class_name,
            "confidence": confidence,
            "image_name": image_name,
            "uploaded_image_url": uploaded_image_url
        })

    return render(request, "upload.html")
