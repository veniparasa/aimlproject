# classifier/utils.py
import tensorflow as tf
from tensorflow.keras.applications.resnet50 import preprocess_input, decode_predictions
from tensorflow.keras.models import load_model
from PIL import Image
import numpy as np

# Load the saved model
model = load_model("resnet50_model.h5")

def predict(image_path):
    # Load and preprocess the image
    image = Image.open(image_path).resize((224, 224))  # ResNet expects 224x224 input
    img_array = np.array(image)
    img_array = preprocess_input(img_array)  # Normalize for ResNet
    img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension

    # Perform prediction
    predictions = model.predict(img_array)
    decoded = decode_predictions(predictions, top=1)[0][0]  # Get top prediction
    class_name, confidence = decoded[1], decoded[2]
    return class_name, confidence
